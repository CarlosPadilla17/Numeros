import Foundation

func mostrarMenu() {
    print("Menu de áreas:\n")
    print("1. Area del cuadrado")
    print("2. Area del rectángulo")
    print("3. Area del triángulo")
    print("4. Area del círculo")
    print("5. Salir")
    print("\nElige una opción (número): ", terminator: "")
}

func calcularAreaCuadrado() {
    print("Introduce el valor del lado: ", terminator: "")
    if let ladoString = readLine(), let lado = Double(ladoString) {
        let area = lado * lado
        print("El área del cuadrado es: \(area)\n")
    } else {
        print("Valor inválido. Inténtalo de nuevo.")
    }
}

func calcularAreaRectangulo() {
    print("Introduce el valor del lado 1: ", terminator: "")
    if let lado1String = readLine(), let lado1 = Double(lado1String) {
        print("Introduce el valor del lado 2: ", terminator: "")
        if let lado2String = readLine(), let lado2 = Double(lado2String) {
            let area = lado1 * lado2
            print("El área del rectángulo es: \(area)\n")
        } else {
            print("Valor inválido. Inténtalo de nuevo.")
        }
    } else {
        print("Valor inválido. Inténtalo de nuevo.")
    }
}

func calcularAreaTriangulo() {
    print("Introduce el valor de la base: ", terminator: "")
    if let baseString = readLine(), let base = Double(baseString) {
        print("Introduce el valor de la altura: ", terminator: "")
        if let alturaString = readLine(), let altura = Double(alturaString) {
            let area = (base * altura) / 2
            print("El área del triángulo es: \(area)\n")
        } else {
            print("Valor inválido. Inténtalo de nuevo.")
        }
    } else {
        print("Valor inválido. Inténtalo de nuevo.")
    }
}

func calcularAreaCirculo() {
    print("Introduce el valor del radio: ", terminator: "")
    if let radioString = readLine(), let radio = Double(radioString) {
        let area = Double.pi * radio * radio
        print("El área del círculo es: \(area)\n")
    } else {
        print("Valor inválido. Inténtalo de nuevo.")
    }
}

var opcionValida = false
while !opcionValida {
    mostrarMenu()
    if let opcion = readLine(), let numeroOpcion = Int(opcion) {
        switch numeroOpcion {
        case 1:
            calcularAreaCuadrado()
        case 2:
            calcularAreaRectangulo()
        case 3:
            calcularAreaTriangulo()
        case 4:
            calcularAreaCirculo()
        case 5:
            print("\nSaliendo...")
            opcionValida = true
        default:
            print("\nPor favor, ingrese un número válido\n")
        }
    } else {
        print("\nPor favor, ingrese un número válido\n")
    }
}