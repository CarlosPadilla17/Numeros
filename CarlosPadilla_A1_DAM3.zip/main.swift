import Foundation

// Definición de una función llamada verificarNumero que toma un número entero como entrada y devuelve una cadena como salida
func verificarNumero(_ numero: Int) -> String {
    // Verifica si el número es divisible entre 2 (es decir, si es par)
    if numero % 2 == 0 {
        // Si el número es par, devuelve una cadena que indica que el número es par
        return "\(numero) es un número par"
    } else {
        // Si el número no es par, devuelve una cadena que indica que el número es impar
        return "\(numero) es un número impar"
    }
}

// Imprime un mensaje solicitando al usuario que ingrese un número
print("Ingrese un número:")

// Lee la entrada del usuario desde la consola y la guarda en una variable llamada 'entradaUsuario'
if let entradaUsuario = readLine(), let numero = Int(entradaUsuario) {
    // Intenta convertir la entrada del usuario en un número entero ('Int(entradaUsuario)')

    // Llama a la función 'verificarNumero' con el número ingresado por el usuario como argumento
    let resultado = verificarNumero(numero)

    // Imprime el resultado de la función 'verificarNumero'
    print(resultado)
}
