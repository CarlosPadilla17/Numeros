import Foundation

var listaArticulos: [(String, Int)] = []
var seRegistraronArticulos = false

func mostrarMenu() {
    print("MENU\n")
    print("1. Registrar artículos")
    print("2. Ver lista de artículos")
    print("3. Consultar artículos en existencia")
    print("4. Salir")
    print("\nElige una opción (número): ", terminator: "")
}

func registrarArticulos() {
    seRegistraronArticulos = true
    var continuarRegistro = true

    while continuarRegistro {
        print("\nIngrese el nombre del artículo, posteriormente presione enter: ", terminator: "")
        if let nombreArticulo = readLine(), !nombreArticulo.isEmpty {
            print("Ingrese la cantidad de este artículo: ", terminator: "")
            if let cantidadString = readLine(), let cantidad = Int(cantidadString) {
                listaArticulos.append((nombreArticulo, cantidad))
                print("\nArtículo registrado con éxito")
            } else {
                print("Cantidad inválida, por favor ingrese un número\n")
            }
        } else {
            print("\nVolviendo al menú anterior...\n")
            continuarRegistro = false
        }
    }
}

func mostrarListaArticulos() {
    if listaArticulos.isEmpty {
        print("\nNo existen registros de artículos\n")
    } else {
        print("\nLista de Artículos:")
        for (index, (nombre, cantidad)) in listaArticulos.enumerated() {
            print("Articulo \(index + 1). \(nombre), Cantidad: \(cantidad)")
        }
        print("\nPresione enter para volver al menú principal")
        if let _ = readLine() {
            print("Volviendo al menú anterior...\n")
        }
    }
}

func consultarArticulos() {
    print("\nIngrese el nombre del artículo para realizar la consulta")

    while true {
        print("\nArticulo: ", terminator: "")
        if let nombreArticulo = readLine(), !nombreArticulo.isEmpty {
            if let cantidad = listaArticulos.first(where: { $0.0 == nombreArticulo })?.1 {
                print("Cantidad: \(cantidad)")
            } else {
                print("Cantidad: 0")
            }
        } else {
            print("\nVolviendo al menú anterior...\n")
            break
        }
    }
}

var opcionValida = false
while !opcionValida {
    mostrarMenu()
    if let opcion = readLine(), let numeroOpcion = Int(opcion) {
        switch numeroOpcion {
        case 1:
            if !seRegistraronArticulos {
                print("\n1. Registro de articulos:")
            }
            registrarArticulos()
        case 2:
            print("\n2. Ver lista de artículos:")
            mostrarListaArticulos()
        case 3:
            print("\n3. Consultar artículos en existencia:")
            consultarArticulos()
        case 4:
            print("\nSaliendo...")
            opcionValida = true
        default:
            print("\nPor favor, ingrese un número válido\n")
        }
    } else {
        print("\nPor favor, ingrese un número válido\n")
    }
}